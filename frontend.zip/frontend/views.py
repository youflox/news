from django.shortcuts import render
from django.contrib.auth.models import User

from api.models import Article

import requests

def homepage(request):
    # url = 'http://homz.pythonanywhere.com/api/list'
    # data = requests.get(url).json()
    # for list in data:
    #     rec = Article(title= list['title'], description= list['description'],
    #               paragraph= 'n/a', author=User.objects.get(id=1), slug=f"{list['id']}slug",
    #                   tags='test', image=list['image'])
    #     rec.save()
    #     print('rec saved')

    # url = 'http://homz.pythonanywhere.com/api/list/'
    # data = requests.get(url).json()
    # carousel=[]
    # top_list=[]
    # main_list=[]
    # for n in range(len(data)):
    #     if n in range(0,2):
    #         carousel.append(data[n])
    #     elif n in range(2,6):
    #         top_list.append(data[n])
    #     else:
    #         main_list.append(data[n])
    #
    # print(data[1]['image'])
    #
    # context = {'carousel': carousel,'top_list': top_list, 'main_list': main_list }
    return render(request, "homepage.html")

